package com.example.tbag.weathercheck.data.event;

/**
 * Created by tbag on 16/5/17.
 */
public class DeviceConnectedEvent {
}
