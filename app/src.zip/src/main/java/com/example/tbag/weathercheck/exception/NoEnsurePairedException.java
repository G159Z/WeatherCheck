package com.example.tbag.weathercheck.exception;

public class NoEnsurePairedException extends Exception {

}
