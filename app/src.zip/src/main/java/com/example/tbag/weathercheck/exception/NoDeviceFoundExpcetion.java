package com.example.tbag.weathercheck.exception;

public class NoDeviceFoundExpcetion extends Exception {

}
